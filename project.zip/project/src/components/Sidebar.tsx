import React from 'react';
import { 
  Home,
  GitPullRequest,
  Settings,
  Users,
  BarChart2,
  Search,
  Code2
} from 'lucide-react';

function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r border-gray-200 p-6">
      <div className="flex items-center mb-8">
        <Code2 className="w-8 h-8 text-blue-600" />
        <h1 className="ml-2 text-xl font-bold text-gray-900">CodeReview</h1>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Search reviews..."
          className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <nav>
        <SidebarLink icon={<Home />} text="Dashboard" active />
        <SidebarLink icon={<GitPullRequest />} text="Pull Requests" />
        <SidebarLink icon={<Users />} text="Team" />
        <SidebarLink icon={<BarChart2 />} text="Analytics" />
        <SidebarLink icon={<Settings />} text="Settings" />
      </nav>
    </aside>
  );
}

interface SidebarLinkProps {
  icon: React.ReactNode;
  text: string;
  active?: boolean;
}

function SidebarLink({ icon, text, active }: SidebarLinkProps) {
  return (
    <a
      href="#"
      className={`flex items-center px-4 py-3 mb-2 rounded-lg text-sm font-medium transition-colors ${
        active
          ? 'bg-blue-50 text-blue-600'
          : 'text-gray-600 hover:bg-gray-50'
      }`}
    >
      <span className="w-5 h-5">{icon}</span>
      <span className="ml-3">{text}</span>
    </a>
  );
}

export default Sidebar;