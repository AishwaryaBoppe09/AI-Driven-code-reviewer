import React from 'react';
import { X } from 'lucide-react';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { github } from 'react-syntax-highlighter/dist/esm/styles/hljs';

interface CodeReviewPanelProps {
  filename: string;
  onClose: () => void;
}

function CodeReviewPanel({ filename, onClose }: CodeReviewPanelProps) {
  const sampleCode = `
function calculateComplexity(code) {
  let complexity = 0;
  const lines = code.split('\\n');
  
  for (const line of lines) {
    if (line.includes('if') || line.includes('for') || line.includes('while')) {
      complexity++;
    }
  }
  
  return complexity;
}
`;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">{filename}</h2>
        <button
          onClick={onClose}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>
      </div>
      
      <div className="p-4">
        <SyntaxHighlighter
          language="javascript"
          style={github}
          customStyle={{
            margin: 0,
            borderRadius: '0.5rem',
            fontSize: '14px',
          }}
        >
          {sampleCode}
        </SyntaxHighlighter>

        <div className="mt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Analysis</h3>
          <div className="space-y-4">
            <ReviewComment
              type="warning"
              message="Consider using a more descriptive variable name than 'complexity'"
              line={2}
            />
            <ReviewComment
              type="suggestion"
              message="You could use regex patterns to make the condition checking more robust"
              line={5}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

interface ReviewCommentProps {
  type: 'warning' | 'suggestion' | 'error';
  message: string;
  line: number;
}

function ReviewComment({ type, message, line }: ReviewCommentProps) {
  const colors = {
    warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
    suggestion: 'bg-blue-50 border-blue-200 text-blue-800',
    error: 'bg-red-50 border-red-200 text-red-800',
  };

  return (
    <div className={`p-4 rounded-lg border ${colors[type]}`}>
      <div className="flex items-start">
        <div className="flex-1">
          <p className="font-medium">Line {line}</p>
          <p className="mt-1 text-sm">{message}</p>
        </div>
      </div>
    </div>
  );
}

export default CodeReviewPanel;