import React, { useState } from 'react';
import { Code2, GitPullRequest, MessageSquare, Search } from 'lucide-react';
import CodeReviewPanel from './components/CodeReviewPanel';
import Sidebar from './components/Sidebar';

function App() {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          <header className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Code Review Dashboard</h1>
            <p className="mt-2 text-gray-600">Review, analyze, and improve code quality</p>
          </header>

          {!selectedFile ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <DashboardCard
                icon={<GitPullRequest className="w-6 h-6" />}
                title="Open Reviews"
                value="12"
                description="Active pull requests"
              />
              <DashboardCard
                icon={<MessageSquare className="w-6 h-6" />}
                title="Comments"
                value="48"
                description="Pending responses"
              />
              <DashboardCard
                icon={<Code2 className="w-6 h-6" />}
                title="Files Changed"
                value="156"
                description="Across all reviews"
              />
            </div>
          ) : (
            <CodeReviewPanel filename={selectedFile} onClose={() => setSelectedFile(null)} />
          )}
        </div>
      </main>
    </div>
  );
}

interface DashboardCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  description: string;
}

function DashboardCard({ icon, title, value, description }: DashboardCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex items-center">
        <div className="p-2 bg-blue-50 rounded-lg">
          {icon}
        </div>
        <div className="ml-4">
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          <p className="text-2xl font-bold text-blue-600 mt-1">{value}</p>
          <p className="text-sm text-gray-500 mt-1">{description}</p>
        </div>
      </div>
    </div>
  );
}

export default App;